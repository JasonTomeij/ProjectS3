import extract_hu_website #test

def main():
    extract_hu_website()

if __name__ == "__main__":
    main()
